def main():
    print("Hello from booklet!")


if __name__ == "__main__":
    main()
